import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.XAI_API_KEY;
const model = process.env.GROK_MODEL || "grok-4.7";
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(apiKey), model });
});

app.post("/api/chat", async (req, res) => {
  if (!apiKey) {
    return res.status(500).json({
      error: "Missing XAI_API_KEY. Copy .env.example to .env and add your xAI API key."
    });
  }

  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Send at least one message." });
  }

  // Accept only ordinary user/assistant text messages; never trust client-supplied system prompts.
  const safeMessages = messages
    .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .slice(-24)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 12000) }));

  if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
    return res.status(400).json({ error: "The latest message must be from the user." });
  }

  const input = [
    {
      role: "system",
      content: [
        "You are JARVIS, a capable, calm, concise personal AI assistant inspired by a futuristic command center.",
        "Be helpful, honest, and practical. Do not claim to have performed actions you have not performed.",
        "You cannot control the user's device, access files, send messages, or execute commands unless a connected tool explicitly enables it.",
        "For potentially destructive, financial, or privacy-sensitive actions, explain risks and ask for confirmation before suggesting execution.",
        "Use clear formatting and ask a brief clarifying question only when needed."
      ].join(" ")
    },
    ...safeMessages
  ];

  try {
    const response = await fetch("https://api.x.ai/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ model, input })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("xAI API error:", response.status, data);
      return res.status(response.status).json({
        error: data?.error?.message || data?.message || `xAI API returned HTTP ${response.status}. Check your API key, credits, and model access.`
      });
    }

    let answer = data.output_text;
    if (!answer && Array.isArray(data.output)) {
      answer = data.output
        .flatMap((item) => item.content || [])
        .filter((item) => item.type === "output_text")
        .map((item) => item.text)
        .join("\n");
    }

    if (!answer) answer = "I received a response, but it did not contain readable text.";
    res.json({ answer, model });
  } catch (error) {
    console.error(error);
    res.status(502).json({ error: "Could not reach the Grok API. Check your internet connection and try again." });
  }
});

app.listen(port, () => {
  console.log(`JARVIS is running at http://localhost:${port}`);
});
